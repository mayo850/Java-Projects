import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		Set<Integer> mySet1 = new HashSet<Integer>();
//		mySet1.add(2);
//		mySet1.add(4);
//		mySet1.add(7);
//		mySet1.add(8);
//		mySet1.add(9);
//		mySet1.add(4);
//		System.out.println("Before: " + mySet1);
//		removeOdds(mySet1);
//		System.out.println("Before: " + mySet1);
//		
//		System.out.println("");
//		
//		Set<Integer> mySet2 = new HashSet<Integer>();
//		mySet2.add(5);
//		mySet2.add(11);
//		mySet2.add(7);
//		mySet2.add(15);
//		mySet2.add(9);
//		System.out.println("Before: " + mySet2);
//		removeOdds(mySet2);
//		System.out.println("Before: " + mySet2);
		
//		Set<String> mySet1 = new HashSet<String>();
//		mySet1.add("Hermione");
//		mySet1.add("Harry");
//		mySet1.add("Ron");
//		mySet1.add("Alberforth");
//		mySet1.add("Wilhelminia");
//		mySet1.add("Draco");
//		System.out.println(longestLength(mySet1));
//		
//		System.out.println("");
//		
//		Set<String> mySet2 = new HashSet<String>();
//		mySet2.add("Gryffindor");
//		mySet2.add("Slytherin");
//		mySet2.add("Ravenclaw");
//		mySet2.add("Hufflepuff");
//		System.out.println(longestLength(mySet2));
		
//		String[] words = {"cat", "dog", "cat", "rat", "bird", "cat", "dog", "bird", "bird", "bird", "pig"};
//		List<String> wordList = Arrays.asList(words);
//		System.out.println(containsAtLeast3(wordList));
//		System.out.println(wordList);
		
		String[] words2 = {"cat", "dog", "rat", "bird", "cat", "dog", "bird", "pig"};
		List<String> wordList2 = Arrays.asList(words2);
		System.out.println(containsAtLeast3(wordList2));
		System.out.println(wordList2);

	}
	
	
	
	public static void  removeOdds(Set<Integer> list) {
		
		Iterator<Integer> itr = list.iterator();
		
		
		while(itr.hasNext()) {
			int element = itr.next();
			
			if(element % 2 != 0 ) {
				itr.remove();
				
			} 
		}
		
	}
	
	public static int longestLength(Set<String> mySet) {
		Iterator<String> itr = mySet.iterator();
		int size = 0;
		
		while(itr.hasNext()) {
			String word = itr.next();
			
			if(word.length() > size) {
				size = word.length();
			}
			
		}
		
		return size;
	}
	
	public static boolean containsAtLeast3(List <String> myList) {
		Iterator<String> itr = myList.iterator();
		HashMap<String , Integer> myMap = new HashMap<String, Integer>();
		
		while(itr.hasNext()) {
		String word = itr.next().toLowerCase();
			
			if(myMap.containsKey(word)) {
				int count = myMap.get(word);
				myMap.put(word, count+1);
			} else {
				myMap.put(word, 1);
			}
			
			if(myMap.get(word) == 3) {
				return true;
			}
			
		}
		
		return false;
	}
	

}
