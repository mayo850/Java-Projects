/**
 * Name: Izan Khan
 * Date: 10/20/2020
 * CSC 371
 * Project 3--ThreeInARow
 * 
 * Program Description:
 * 	Three In A Row puzzle, fill an N*N grid where N is always even with blue
 *  and white squares so that each row and column has the same number
 *  of each color and there are not three adjacent squares of the same color.
 *  This Program will be implementing BackTracking.
 * 
 * 
 * Cite assistance (who and what):
 * 
 * 
 * 
 */

// I used this when debugging
import java.util.*;
import java.io.*;

public class ThreeInRowSolver {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner console = new Scanner(System.in);
		Scanner fileIn = getFileScanner(console);
		char[][] board = read(fileIn);
		
		System.out.println("\nInitial Board: ");
		print(board);
		
		System.out.println("\n");
		System.out.println("Solution:");
		
		if (solveThreeInRow(board))
			print(board);
		else
			System.out.println("No solution");
	}

	/**
	 * Requires the user to enter a filename until the filename is valid
	 * 
	 * @param console - facilitates keyboard input
	 * @return Scanner connected to the input file
	 * @throws FileNotFoundException if the file is not found
	 */
	public static Scanner getFileScanner(Scanner console) throws FileNotFoundException {
		System.out.print("Enter the filename with the puzzle: ");
		String filename = console.nextLine();
		File inputFile = new File(filename);
		while (!inputFile.canRead()) {
			System.out.println("Error. File cannot be found or cannot be read.");
			System.out.print("Enter the filename with the puzzle: ");
			filename = console.nextLine();
			inputFile = new File(filename);
		}
		return new Scanner(inputFile);
	}

	/**
	 * Input a selected file into a 2 Dimensional Array of char and print's an
	 * output of the initial board. Takes the first positive integer from file i.e
	 * the size of N*N board.
	 * 
	 * @param file - facilitates input from the keyboard
	 * @return - initial board created from the input file.
	 */

	public static char[][] read(Scanner file) {

		int lines = Integer.parseInt(file.nextLine());

		char[][] board = new char[lines][lines];

		for (int i = 0; i < board.length; i++) {
			String line = file.nextLine();
			for (int j = 0; j < board[i].length; j++) {
				board[i][j] = line.charAt(j);
			}
		}
		return board;
	}
	
	
	public static void print(char[][] board) {
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[i].length; j++) {
				System.out.print(board[i][j] + " ");
			}
			System.out.print("\n");
		}
	}
	
	public static int findBlankCell(char[][] board) {
		for (int row = 0; row < board.length; row++) {
			for (int col = 0; col < board.length; col++) {
				if (board[row][col] == '-') {
					return row * board.length + col;
				}
			}
		}
		return -1; // means grid is full
	}
	
	private static boolean isSafe(char[][] board, char letter, int row, int col) {
		// checking in row
		
		for (int i = 0; i < board.length; i++) {
			// there is a cell with same value
			int count = 0;
			if (board[row][i] == letter)
				count = count + 1;
				if(count == board.length/2) {
					return false;
				}
		}
		// checking column
		
		for (int i = 0; i < board.length; i++) {
			int count = 0;
			// there is a cell with same value
			if (board[i][col] == letter)
				count = count+ 1;
				if(count == board.length/2) {
					return false;
				}
				
		}
		
		return true;
	}
	
	private static boolean solveThreeInRow(char[][] board) {
		int blankCell = findBlankCell(board);
		if (blankCell == -1) {
			// means no cells are blank and the puzzle is solved
			return true;
		}

		int row = blankCell / board.length;
		int col = blankCell % board.length;
		
		Character[] letter = new Character[2];
		
		letter[0] = 'W';
		letter[1]= 'B';
		
		
		
		for (int i = 0; i <= letter.length -1; i++) {
			// Can assign i to the cell or not?
			// The cell is board[row][col].
			if (isSafe(board, letter[i], row, col)) {
				board[row][col] = letter[i];
				// backtracking
				if (solveThreeInRow(board))
					return true;
				// Ff we can't proceed with this solution,
				// reassign the cell
				board[row][col] = 0;
			}
		}
		return false;
	}
	
	

}
