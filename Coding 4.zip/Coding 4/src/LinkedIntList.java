public class LinkedIntList{

	private ListNode front; // first value in the list

	public LinkedIntList() {
		front = null;
	}


	/**
	 * creates comma separated, bracketed version of the list
	 * @return a String of the form [2, 5, 7]
	 */
	public String toString() {
		if (front == null) {
			return "[]";
		} else {
			String result = "[" + front.data;
			ListNode current = front.next;
			while (current != null) {
				result += ", " + current.data;
				current = current.next;
			}
			result += "]";
			return result;
		}
	}
	
	/**
	 * creates a linked looking version of the list
	 * @return String of this form: front -> [2] -> [5] -> [7]/
	 */
	public String toLinkedForm() {
		if (front == null) {
			return "front /";
		} else {
			String result = "front -> [" + front.data + "] ";
			ListNode current = front.next;
			while (current != null) {
				result += "-> [" + current.data + "] ";
				current = current.next;
			}
			result += "/";
			return result;
		}
	}
	
	
	/**
	 * adds elements from the array to a linked list
	 * @param array - elements to be added to linked list
	 * 
	 * Let's you use code like this in the client to more easily 
	 * create a linked list.
	 * LinkedIntList myList = new LinkedIntList();
	 * int[] array = {5, 4, 9};
	 * myList.createListFromArray(array);
	 */
	public void createListFromArray(int[] array) {
		for (int i = array.length - 1; i >=0; i--) {
			front = new ListNode(array[i], front);
		}
	}
	
	
	
    private class ListNode {
		private int data; // data stored in this node
		private ListNode next; // link to next node in the list

		/**
		 * post: constructs a node with data 0 and null link
		 */
		private ListNode() {
			this(0, null);
		}

		private ListNode(int data) {
			this(data, null);
		}

		private ListNode(int data, ListNode next) {
			this.data = data;
			this.next = next;
		}
	}
}