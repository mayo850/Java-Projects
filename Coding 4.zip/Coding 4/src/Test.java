
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] myArray = {5, 4, 9};
		
		LinkedIntList myList = new LinkedIntList();
		

		myList.createListFromArray(myArray);
		
		System.out.println("Before: " + myList.toLinkedForm());
		//myList.addBeginAndEnd(100);
		//System.out.println("After: " + myList.toLinkedForm());
	}

}
