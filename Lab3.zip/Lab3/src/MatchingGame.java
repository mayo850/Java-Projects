
/**
 * Name: Izan 
 * Date: 09/29/2020
 * CSC 371
 * Lab 3--MatchingGame.java
 * 
 * MatchingGame plays a solitaire type game where adjacent pairs of numbers 
 * with the same 10s digit or the same 1s digit  in a list are removed. 
 * If all numbers are removed from the list, you win!
 */
import java.util.*;

public class MatchingGame {

	public static final int LIST_NUM = 20;
	public static final int RANGE = 90;
	public static final int LOW_NUM = 10;

	public static void main(String[] args) {

		// Create a list of random integers to begin the game
		List<Integer> numbers = new LinkedList<Integer>();
		Random rand = new Random();
		for (int i = 0; i < LIST_NUM; i++) {
			numbers.add(rand.nextInt(RANGE) + LOW_NUM);
		}
	
		System.out.println("Matching Game");
		System.out.println("Initial list: " + numbers);

		// Get a ListIterator to process the list
		ListIterator<Integer> itr = numbers.listIterator();

		// implement the game using the ListIterator
		int first = itr.next();
		while (itr.hasNext()) {
			int second = itr.next();
			if (first % 10 == second % 10 || first % 100 - first % 10 == second % 100 - second % 10) {
				itr.remove();
				if (itr.hasPrevious()) {
					itr.previous();
					itr.remove();
				}
				System.out.println();
				System.out.println("Removed: " + first + ", " + second);
				System.out.println("udpadte list: " + numbers);
				if (itr.hasPrevious()) {
					first = itr.previous();
					second = itr.next();
				} else if (itr.hasNext()){
					second = itr.next();
					first = second;
				}
			} else if (itr.hasNext()) {
				first = second;
			}

		}

		// Output the results
		if (numbers.isEmpty()) {
			System.out.println("\nYou Win!");
		} else {
			System.out.println("\nTry Again. There were " + numbers.size() + " values left.");
		}

	}

}
