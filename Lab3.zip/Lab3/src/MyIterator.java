import java.util.Iterator;
import java.util.NoSuchElementException;



 class MyIterator<E> implements Iterator<E>{

	 
	 private int current = 0;
	 
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E next() {
		if (!hasNext()) {
			throw new NoSuchElementException("No next element");
		}
		return null;
		
	}
	        
	 
	

}
