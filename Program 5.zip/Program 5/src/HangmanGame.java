
/**
 * Name:
 * Date:
 * CSC 371
 * Program Project 5--HangmanGame
 *
 * Description:
 * 
 * Cite Assistance (who and what):
 * 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class HangmanGame {
	private int guesses;
	private String currentPattern;
	private TreeSet considerations;
	private TreeSet guessed;
	private TreeMap myMap;

	public static void main(String[] args) throws FileNotFoundException {
		// open the dictionary file and read dictionary into an ArrayList
		Scanner input = new Scanner(new File("dictionary2.txt"));
		List<String> dictionary = new ArrayList<String>();
		while (input.hasNext()) {
			dictionary.add(input.next().toLowerCase());
		}
//		HangmanGame game = new HangmanGame(dictionary, 4, 10);

		input.close();

	}

	public HangmanGame(List<String> dictionary, int length, int maximum) {
		if (length < 1 || maximum < 0) {
			throw new IllegalArgumentException();
		}

		guesses = maximum;
		currentPattern = "-";
		considerations = new TreeSet<String>();
		guessed = new TreeSet<Character>();
		myMap = new TreeMap<String, TreeSet<String>>();

		for (int i = 0; i < length-1; i++) {
			currentPattern += " " + "-";
		}

		Iterator<String> itr = dictionary.iterator();

		while (itr.hasNext()) {
			String word = itr.next();

			if (word.length() == length) {
				considerations.add(word);
			}
		}

	}

	public Set<String> getWordsLeft() {
		return considerations;
	}

	public int getNumWrongGuessesLeft() {
		return guesses;
	}

	public Set<Character> getGuessedLetters() {
		return guessed;
	}

	public String getCurrentPattern() {
		if (considerations.isEmpty()) {
			throw new IllegalStateException();
		}

		return currentPattern;

	}

	public int processGuess(char guess) {
		return 0; 
	}

	
}
