
public class recursion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		System.out.println(multiplyOdds(4));

		
		double result = sumEvenReciprocals(2);
		System.out.println(result);
	}
	
	public static int multiplyOdds(int odd) {
		if(odd <= 0) {
			throw new IllegalArgumentException();
		}
		
		if(odd == 1) {
			return 1;
		}
		
		return (2 * odd - 1) * multiplyOdds(odd -1) ;
		
	}
	
	
	public static double sumEvenReciprocals(int even) {
		if(even <= 0) {
			throw new IllegalArgumentException();
		}
		double num = even;
		
		if(even == 1) {
			
			return num/2;
		}
		
		
		return 1 / (2 * num) + sumEvenReciprocals(even - 1);
	}
}

